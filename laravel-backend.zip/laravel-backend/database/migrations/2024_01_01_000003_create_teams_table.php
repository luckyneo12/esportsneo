<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('teams', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('logo_url')->nullable();
            $table->foreignId('tower_id')->constrained('towers')->onDelete('cascade');
            $table->foreignId('captain_id')->constrained('users')->onDelete('cascade');
            $table->integer('total_points')->default(0);
            $table->timestamps();
            
            $table->unique(['name', 'tower_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('teams');
    }
};
